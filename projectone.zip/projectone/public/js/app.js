angular.module('crud', ['ui.router'])

.run(function ($rootScope) {
$rootScope.safeApply = function(fn) {
      var phase = this.$root.$$phase;
      if (phase == '$apply' || phase == '$digest') {
        if (fn && (typeof(fn) === 'function')) {
          fn();
        }
      } else {
        this.$apply(fn);
      }
    };
})

.config(function($stateProvider, $urlRouterProvider) {
	$stateProvider

	.state('login', {
		url: '/login',
		templateUrl: 'tpl/login.html',
		controller: function($scope, $http, $httpParamSerializer, $location) {
			$scope.loginForm = {};
			$scope.login = function () {
		            var request = $http({
		                method: "post",
		                url: "http://www.smscentral.in/portal/api/login",
		                data: $httpParamSerializer($scope.loginForm),
		                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
		            });

		            /* Successful HTTP post request or not */
		            request.then(function (data) {
		            //$scope.results = [];
		            // $scope.results = data;
		            	 console.log(data.data.response);

		            //$scope.results
		                if(data.data.response == 1){
		                    $scope.responseMessage = "Successfully Logged In";
		                     $location.path("/userlist");
		                    // $window.location.href='http://www.google.com';

		                }
		                else {
		                    $scope.responseMessage = "Username or Password is incorrect";
		                }
		            });
		    }
		}
	})

	.state('userlist', {
		url: '/userlist',
		templateUrl: 'tpl/userlist.html'
	})

	.state('register', {
		url: '/register',
		templateUrl: 'tpl/register.html'
	})

	.state('listdevices', {
		url: '/listdevices',
		templateUrl: 'tpl/listdevices.html',
		controller: function($scope, $http) {
			$scope.devices = [];
			$http({method: 'GET', url: 'http://gps.cobrasoftwares.in:8082/api/devices', headers: {
		            'Authorization': 'Basic YWRpQGNvYnJhc29mdHdhcmVzLmluOmphY2sxMjM0'}
		        }).then(function(resp) {
		            // $scope.devices = resp;
		            console.log('resp');
		        });
		}
	});

$urlRouterProvider.otherwise('/login');
});
